### Test Case for Website Functionality

![image](https://user-images.githubusercontent.com/103220318/163633652-f5dd09ef-a757-4dea-97db-869ecf9cd974.png)

### Test Case for Login

![image](https://user-images.githubusercontent.com/103220318/163655205-ae7067f7-c035-411b-9e9b-c39f00ee100f.png)

### Product Information

![image](https://user-images.githubusercontent.com/103220318/163655221-276fe915-91e6-4282-bc89-ec7e73ac13ef.png)


### Inventory

![image](https://user-images.githubusercontent.com/103220318/163655254-aaf268dd-67a4-409e-8d67-62e1a7559a60.png)

### Delivery 

![image](https://user-images.githubusercontent.com/103220318/163655275-bc6b5a44-0dcd-4e1b-a5be-998f0845cda5.png)


### Cart

![image](https://user-images.githubusercontent.com/103220318/163655279-3ee63c28-493a-40a2-b439-930a1cdaf829.png)

### Shipping Information

![image](https://user-images.githubusercontent.com/103220318/163655303-7b9cf27d-0195-46ed-815b-0eeb7e04f053.png)

### Payment

![image](https://user-images.githubusercontent.com/103220318/163655323-2cbbed04-7f58-438f-9201-2a1b0dcc511e.png)

### Order History

![image](https://user-images.githubusercontent.com/103220318/163655356-79ae5d0d-008d-4e7b-ac00-2e2f3af7fe0b.png)


# Testcases Linked with the Use Cases/Requirements

![image](https://user-images.githubusercontent.com/103220318/163655402-98b264da-deb6-4334-8406-c44f08585a11.png)

![image](https://user-images.githubusercontent.com/103220318/163655438-0d1aba72-7934-46af-96b8-7ee48a473226.png)

![image](https://user-images.githubusercontent.com/103220318/163655462-a0f43d29-5d67-4433-85e2-716620476b4c.png)

![image](https://user-images.githubusercontent.com/103220318/163655487-6ecd03f5-f6fa-4e67-80a4-5b98f6618426.png)

![image](https://user-images.githubusercontent.com/103220318/163655497-3c3bf702-e8f9-4a10-b0a6-12f803368b85.png)
