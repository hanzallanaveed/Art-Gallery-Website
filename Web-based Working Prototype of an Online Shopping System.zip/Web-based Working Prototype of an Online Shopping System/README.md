# final-project-W22-SOFE-2720-G19
Project description 
Customers till this day go out of there way to drive to the grocery store and waste time shopping for groceries that are not natural and have been sitting there for who knows how long. That is where we come in with Fresh Produce Delivery. We have made fresh picked groceries deliverable on the same day from our producers all at the comfort of you home. You get in to the website add all your favourite groceries and have them shipped to your house while saving time through out your day to do other more important things. Our company started just over a year a ago due to the complaints I have seen towards nearby grocery stores for the very reason that there groceries are not fresh, they have to wait in a long line for hours, bad customer servic. All these problems are solved with Fresh Produce Delivery, "Once you go Fresh you'll never go back".
Content
Code
Design 
Requirments
Test Case 
Use Case
