This is the folder in which will contain all relivant use cases diagrams and their descriptions 
